package com.example.pisotab

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val BASE_URL = "http://192.168.1.10:3000"
    private val DEVICE_ID = "TAB-01"
    private val DEVICE_TOKEN = "PASTE_DEVICE_TOKEN_HERE"

    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var status: TextView
    private lateinit var instruction: TextView
    private lateinit var payButton: Button

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun makeText(textValue: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = textValue
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val background = Color.rgb(15, 23, 42)
        val white = Color.WHITE
        val green = Color.rgb(34, 197, 94)
        val muted = Color.rgb(203, 213, 225)

        status = makeText("READY TO CONNECT", 20f, white, true)
        instruction = makeText(
            "Tap the button below, then insert your coin at the central coin acceptor.",
            16f, muted
        )

        payButton = Button(this).apply {
            text = "INSERT MONEY / ADD TIME"
            textSize = 18f
            isAllCaps = false
            setOnClickListener { requestPayment() }
        }

        val title = makeText("PISOTAB", 34f, green, true)
        val subtitle = makeText("CENTRALIZED INTERNET VENDO", 13f, muted, true)
        val accepted = makeText("ACCEPTED COINS", 15f, green, true)
        val denominations = makeText("₱1     ₱5     ₱10     ₱20", 24f, white, true)
        val footer = makeText("Developed by Jabin Cajes", 12f, muted)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(24), dp(22), dp(24))
            setBackgroundColor(background)
            addView(title)
            addView(subtitle)
            addView(space(24))
            addView(status)
            addView(space(12))
            addView(instruction)
            addView(space(22))
            addView(accepted)
            addView(denominations)
            addView(space(22))
            addView(payButton, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(64)
            ))
            addView(space(28))
            addView(footer)
        }

        setContentView(layout)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )
        poll()
    }

    private fun space(heightDp: Int): View =
        View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(heightDp)) }

    private fun requestPayment() {
        payButton.isEnabled = false
        status.text = "CONNECTING TO COIN STATION..."
        instruction.text = "Please wait. Do not insert a coin until the request is active."

        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = URL("$BASE_URL/api/device/request-payment")
                    .openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                val body = JSONObject()
                    .put("deviceId", DEVICE_ID)
                    .put("token", DEVICE_TOKEN)
                    .toString()
                connection.outputStream.use { it.write(body.toByteArray()) }

                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)

                handler.post {
                    if (code in 200..299) {
                        status.text = "INSERT YOUR COIN NOW"
                        instruction.text = "Your tablet is assigned to the coin station. Insert ₱1, ₱5, ₱10 or ₱20."
                        payButton.text = "WAITING FOR PAYMENT"
                    } else {
                        status.text = "COIN STATION BUSY"
                        instruction.text = json.optString(
                            "error",
                            "Please wait, then tap Insert Money again."
                        )
                        payButton.isEnabled = true
                        payButton.text = "TRY AGAIN"
                    }
                }
            } catch (e: Exception) {
                handler.post {
                    status.text = "CONNECTION ERROR"
                    instruction.text = "Check Wi-Fi and the PisoTab server, then try again."
                    payButton.isEnabled = true
                    payButton.text = "TRY AGAIN"
                }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun poll() {
        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = URL("$BASE_URL/api/device/heartbeat")
                    .openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.connectTimeout = 5000
                connection.readTimeout = 5000
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                val body = JSONObject()
                    .put("deviceId", DEVICE_ID)
                    .put("token", DEVICE_TOKEN)
                    .toString()
                connection.outputStream.use { it.write(body.toByteArray()) }

                val json = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                val active = json.optBoolean("active")
                val pending = json.optBoolean("paymentPending")
                val end = json.optLong("endsAt")

                handler.post {
                    when {
                        active -> {
                            val seconds = ((end - System.currentTimeMillis()).coerceAtLeast(0L) / 1000)
                            status.text = "INTERNET SESSION ACTIVE"
                            instruction.text = "TIME REMAINING: ${seconds / 60}m ${seconds % 60}s"
                            payButton.text = "INSERT MONEY / ADD TIME"
                            payButton.isEnabled = true
                            try { startLockTask() } catch (_: Exception) {}
                        }
                        pending -> {
                            status.text = "INSERT YOUR COIN NOW"
                            instruction.text = "Payment request is active. Use the central coin acceptor."
                            payButton.text = "WAITING FOR PAYMENT"
                            payButton.isEnabled = false
                        }
                        else -> {
                            status.text = "READY TO CONNECT"
                            instruction.text = "Tap below to reserve the coin acceptor for this tablet."
                            payButton.text = "INSERT MONEY / ADD TIME"
                            payButton.isEnabled = true
                            try { stopLockTask() } catch (_: Exception) {}
                        }
                    }
                }
            } catch (_: Exception) {
                handler.post {
                    status.text = "SERVER CONNECTION UNAVAILABLE"
                    instruction.text = "Check your Wi-Fi connection."
                    payButton.isEnabled = true
                }
            } finally {
                connection?.disconnect()
            }
            handler.postDelayed({ poll() }, 3000)
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
