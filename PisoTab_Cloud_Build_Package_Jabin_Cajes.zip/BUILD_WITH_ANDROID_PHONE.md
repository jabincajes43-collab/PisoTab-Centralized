# Build PisoTab APK using only an Android phone

You do not need Android Studio on your phone. This project includes a GitHub Actions
cloud build workflow. GitHub will build the debug APK on its servers.

## Steps

1. In Chrome on your Android phone, open https://github.com and sign in or create an account.
2. Create a new repository named `PisoTab-Centralized`. For a private project, choose **Private**.
3. Open the new repository, choose **Add file** -> **Upload files**.
4. Upload the contents of this ZIP (extract it first using your phone's Files app; include
   the `.github` folder). Commit the upload to the repository's main branch.
5. In the repository, open **Actions**. If prompted, enable GitHub Actions.
6. Select **Build PisoTab APK** and tap **Run workflow**. Wait for the run to finish.
7. Open the completed run, scroll to **Artifacts**, and download `PisoTab-debug-apk`.
8. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Tap it to install.
   Android may ask you to allow installs from that browser or file manager.

## Important: this build is only a debug APK

A successful compile does NOT mean the payment system is ready for real money.
Before live use, configure the server URL and per-tablet device token in
`android/app/src/main/java/com/example/pisotab/MainActivity.kt`, then rebuild.
The current sample server generates random device tokens at first startup; the
project still needs a secure device-provisioning step so the token can be retrieved
and assigned to each tablet. The sample backend also requires a reachable server
and ESP32 API key. Do not connect the coin acceptor for live sales until those
items and the pulse calibration have been tested.

## Phone upload tip

Some Android file managers hide dot-folders. Make sure `.github/workflows/android-apk.yml`
is included in the repository. If GitHub's browser uploader does not show `.github`,
create the folders and file directly in GitHub using **Add file** -> **Create new file**,
then name it `.github/workflows/android-apk.yml` and paste the workflow contents from
this project's ZIP.

## Project files

- `android/` Android tablet app source
- `backend/` central server source
- `firmware/` ESP32 coin pulse firmware
- `wiring.md` hardware wiring precautions
- `README.md` setup and testing notes
