#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

// -------- EDIT THESE SETTINGS --------
const char* WIFI_SSID = "YOUR_WIFI";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* BACKEND_URL = "http://192.168.1.10:3000/api/coin";
const char* API_KEY = "CHANGE_THIS_TO_A_LONG_RANDOM_KEY";
const int COIN_PIN = 27;             // isolated optocoupler output only
const unsigned long QUIET_MS = 250;  // pulse train ends after this quiet period
const unsigned long MIN_PULSE_GAP_MS = 25;
// -------------------------------------

volatile uint32_t pulseCount = 0;
volatile unsigned long lastPulseAt = 0;
volatile unsigned long lastEdgeAt = 0;

void IRAM_ATTR onCoinPulse() {
  unsigned long now = millis();
  if (now - lastEdgeAt >= MIN_PULSE_GAP_MS) {
    pulseCount++;
    lastPulseAt = now;
    lastEdgeAt = now;
  }
}

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }
}

bool sendCoinPulses(uint32_t pulses) {
  if (WiFi.status() != WL_CONNECTED) return false;
  HTTPClient http;
  http.begin(BACKEND_URL);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-API-Key", API_KEY);

  StaticJsonDocument<128> doc;
  doc["pulses"] = pulses;
  doc["source"] = "esp32-central-coin";
  String body;
  serializeJson(doc, body);

  int code = http.POST(body);
  http.end();
  return code >= 200 && code < 300;
}

void setup() {
  Serial.begin(115200);
  pinMode(COIN_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(COIN_PIN), onCoinPulse, FALLING);
  connectWiFi();
  Serial.println("PisoTab central coin controller ready");
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
  }

  uint32_t batch = 0;
  unsigned long last = 0;

  noInterrupts();
  last = lastPulseAt;
  if (pulseCount > 0 && millis() - last >= QUIET_MS) {
    batch = pulseCount;
    pulseCount = 0;
  }
  interrupts();

  if (batch > 0) {
    Serial.printf("Coin pulse batch: %u\\n", batch);
    if (!sendCoinPulses(batch)) {
      Serial.println("Failed to report pulses. Check Wi-Fi/backend.");
      // Deliberately do not auto-credit offline: avoids lost/duplicate payments.
      // Add a persistent retry queue only after transaction IDs are implemented.
    }
  }
  delay(10);
}
